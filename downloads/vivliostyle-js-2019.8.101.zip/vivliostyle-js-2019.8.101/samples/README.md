You can find other samples at [Vivliostyle Samples](https://vivliostyle.org/samples/)
or at the [vivliostyle_doc](https://github.com/vivliostyle/vivliostyle_doc) repository.
