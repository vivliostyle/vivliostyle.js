This directory contains Adaptive Layout samples from http://sorotokin.com/adaptive-layout/ .
