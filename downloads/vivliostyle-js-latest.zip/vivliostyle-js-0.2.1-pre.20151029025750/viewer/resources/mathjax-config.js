/*
 * Copyright 2015 Vivliostyle Inc.
 */

window.MathJax = {
    showProcessingMessages: false,
    messageStyle: "none"
};
